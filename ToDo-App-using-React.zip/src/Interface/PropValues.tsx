export interface PropValues {
  id: number;
  task: string;
}
