import styles from './TodoAddButton.module.css'
function TodoAddButton() {
    return (
        <button className={styles['add-button']}>+</button>
    )
}

export default TodoAddButton;